To run the R codes, paste the files present in this directory (six R files 
and two directories) inside the raw data directory downloaded from the hospital
compare website (i.e. the directory you download from hospital compare should contain
all the raw data files, PDFs and the R files and two directories present in this directory).